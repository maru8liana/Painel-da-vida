'use strict';
// Painel da Vida — servidor sem dependências (Node >= 18).
// Senhas com scrypt + salt, sessões em cookie HttpOnly, dados separados por usuário.
const http = require('http'), fs = require('fs'), path = require('path'), crypto = require('crypto');
const PORT = process.env.PORT || 3000;
const DIR = process.env.DATA_DIR || path.join(__dirname, 'data');
const PROD = process.env.NODE_ENV === 'production';
const HTML = path.join(__dirname, 'index.html');
const UF = path.join(DIR, 'usuarios.json'), SF = path.join(DIR, 'sessoes.json');
fs.mkdirSync(path.join(DIR, 'estados'), { recursive: true });

const load = (f, d) => { try { return JSON.parse(fs.readFileSync(f, 'utf8')); } catch (_) { return d; } };
const save = (f, o) => { const t = f + '.' + process.pid + '.tmp'; fs.writeFileSync(t, JSON.stringify(o)); fs.renameSync(t, f); };
const sha = s => crypto.createHash('sha256').update(s).digest('hex');
const scrypt = (s, salt) => new Promise((ok, no) => crypto.scrypt(s, salt, 64, (e, k) => e ? no(e) : ok(k)));
let users = load(UF, {}), sess = load(SF, {});
const purge = () => { const n = Date.now(); for (const k in sess) if (sess[k].exp < n) delete sess[k]; };
purge();

const send = (res, code, obj, h = {}) => {
  res.writeHead(code, { 'Content-Type': 'application/json; charset=utf-8', 'Cache-Control': 'no-store', 'X-Content-Type-Options': 'nosniff', ...h });
  res.end(JSON.stringify(obj));
};
const readBody = (req, max) => new Promise((ok, no) => {
  let n = 0; const c = [];
  req.on('data', d => { n += d.length; if (n > max) { no(Object.assign(new Error('Muito grande'), { code: 413 })); req.destroy(); } else c.push(d); });
  req.on('end', () => { try { ok(JSON.parse(Buffer.concat(c).toString() || '{}')); } catch (_) { no(Object.assign(new Error('JSON inválido'), { code: 400 })); } });
  req.on('error', no);
});
const secure = req => PROD || req.headers['x-forwarded-proto'] === 'https';
const tokenOf = req => { const m = /(?:^|; )sid=([a-f0-9]{64})(?:;|$)/.exec(req.headers.cookie || ''); return m && m[1]; };
const current = req => {
  const t = tokenOf(req), s = t && sess[sha(t)];
  if (!s || s.exp < Date.now()) return null;
  const u = users['u:' + s.u];
  return u ? { id: u.id, usuario: s.u, nome: u.nome } : null;
};
const login = (req, res, usuario, code) => {
  const tok = crypto.randomBytes(32).toString('hex'), age = 30 * 864e5;
  purge(); sess[sha(tok)] = { u: usuario, exp: Date.now() + age }; save(SF, sess);
  const ck = `sid=${tok}; HttpOnly; SameSite=Lax; Path=/; Max-Age=${age / 1000}${secure(req) ? '; Secure' : ''}`;
  const u = users['u:' + usuario];
  send(res, code, { user: { id: u.id, usuario, nome: u.nome } }, { 'Set-Cookie': ck });
};

// limite simples de tentativas por IP (10 a cada 10 min)
const tries = new Map();
const ipOf = req => (req.headers['x-forwarded-for'] || '').split(',')[0].trim() || req.socket.remoteAddress;
const blocked = ip => { const t = tries.get(ip); return t && t.n >= 10 && Date.now() - t.t < 6e5; };
const fail = ip => { const t = tries.get(ip); const n = Date.now(); tries.set(ip, !t || n - t.t >= 6e5 ? { n: 1, t: n } : { n: t.n + 1, t: t.t }); };
setInterval(() => { const n = Date.now(); for (const [k, v] of tries) if (n - v.t >= 6e5) tries.delete(k); }, 6e5).unref();

const RE_USER = /^[a-z0-9._-]{3,30}$/;
const stateFile = id => path.join(DIR, 'estados', id + '.json');

async function api(req, res, p) {
  if (req.method !== 'GET') {
    const o = req.headers.origin;
    if (o) { let h; try { h = new URL(o).host; } catch (_) { } if (h !== req.headers.host) return send(res, 403, { erro: 'Origem não permitida.' }); }
    if (!/^application\/json/i.test(req.headers['content-type'] || '') && p !== 'sair') return send(res, 415, { erro: 'Formato inválido.' });
  }
  const ip = ipOf(req);
  if (p === 'me' && req.method === 'GET') return send(res, 200, { servidor: true, user: current(req) });

  if (p === 'registro' && req.method === 'POST') {
    if (blocked(ip)) return send(res, 429, { erro: 'Muitas tentativas. Aguarde alguns minutos.' });
    fail(ip);
    const b = await readBody(req, 4096);
    const usuario = String(b.usuario || '').trim().toLowerCase(), senha = String(b.senha || ''), nome = String(b.nome || '').trim().slice(0, 40);
    if (!RE_USER.test(usuario)) return send(res, 400, { erro: 'Usuário: 3 a 30 caracteres, só letras minúsculas, números, ponto, _ e -.' });
    if (senha.length < 8 || senha.length > 128) return send(res, 400, { erro: 'A senha precisa ter de 8 a 128 caracteres.' });
    if (users['u:' + usuario]) return send(res, 409, { erro: 'Esse nome de usuário já está em uso.' });
    const salt = crypto.randomBytes(16).toString('hex');
    users['u:' + usuario] = { id: crypto.randomBytes(8).toString('hex'), nome, salt, hash: (await scrypt(senha, salt)).toString('hex') };
    save(UF, users);
    return login(req, res, usuario, 201);
  }

  if (p === 'login' && req.method === 'POST') {
    if (blocked(ip)) return send(res, 429, { erro: 'Muitas tentativas. Aguarde alguns minutos.' });
    const b = await readBody(req, 4096);
    const usuario = String(b.usuario || '').trim().toLowerCase(), senha = String(b.senha || '').slice(0, 128);
    const u = users['u:' + usuario];
    const calc = await scrypt(senha, u ? u.salt : 'x'.repeat(32));
    const ok = u && crypto.timingSafeEqual(calc, Buffer.from(u.hash, 'hex'));
    if (!ok) { fail(ip); return send(res, 401, { erro: 'Usuário ou senha incorretos.' }); }
    tries.delete(ip);
    return login(req, res, usuario, 200);
  }

  if (p === 'sair' && req.method === 'POST') {
    const t = tokenOf(req); if (t) { delete sess[sha(t)]; save(SF, sess); }
    return send(res, 200, { ok: true }, { 'Set-Cookie': `sid=; HttpOnly; SameSite=Lax; Path=/; Max-Age=0${secure(req) ? '; Secure' : ''}` });
  }

  const u = current(req);
  if (!u) return send(res, 401, { erro: 'Sessão expirada. Entre novamente.' });
  if (p === 'estado' && req.method === 'GET') return send(res, 200, { dados: load(stateFile(u.id), null) });
  if (p === 'estado' && req.method === 'PUT') {
    const b = await readBody(req, 2e6);
    if (!b || typeof b.estado !== 'object' || b.estado === null) return send(res, 400, { erro: 'Dados inválidos.' });
    save(stateFile(u.id), { estado: b.estado, em: Number(b.em) || Date.now() });
    return send(res, 200, { ok: true });
  }
  return send(res, 404, { erro: 'Não encontrado.' });
}

http.createServer(async (req, res) => {
  try {
    const url = new URL(req.url, 'http://x'), p = url.pathname;
    if (p.startsWith('/api/')) return await api(req, res, p.slice(5));
    if ((req.method === 'GET' || req.method === 'HEAD') && (p === '/' || p === '/index.html')) {
      const h = {
        'Content-Type': 'text/html; charset=utf-8', 'Cache-Control': 'no-cache', 'X-Content-Type-Options': 'nosniff',
        'X-Frame-Options': 'DENY', 'Referrer-Policy': 'same-origin',
        'Content-Security-Policy': "default-src 'self'; script-src 'self' 'unsafe-inline'; style-src 'self' 'unsafe-inline' https://fonts.googleapis.com; font-src https://fonts.gstatic.com; img-src 'self' data:; connect-src 'self'; frame-ancestors 'none'; base-uri 'none'; form-action 'self'"
      };
      if (secure(req)) h['Strict-Transport-Security'] = 'max-age=31536000';
      res.writeHead(200, h); return res.end(req.method === 'HEAD' ? undefined : fs.readFileSync(HTML));
    }
    res.writeHead(404, { 'Content-Type': 'text/plain; charset=utf-8' }); res.end('Não encontrado');
  } catch (e) {
    if (!res.headersSent) send(res, e.code === 413 || e.code === 400 ? e.code : 500, { erro: e.code ? e.message : 'Erro interno.' });
  }
}).listen(PORT, () => console.log('Painel da Vida em http://localhost:' + PORT));
